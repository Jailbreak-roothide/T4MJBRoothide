# AdShield changelog

Credit: Jinken Nguyen - 1989

## 1.4.0 (2026-09-14)

### Tiếng Việt
- Hết Safe Mode / treo táo: không load WebKit/AVFoundation lúc boot, không link libroothide vào SpringBoard.
- Constructor C chặn SplashBoard, SpringBoard, Sileo và daemon hệ thống trước khi chạy Objective-C.
- Ổn định trên iOS 14–18 / RootHide / rootless / rootful.

### English
- No more Safe Mode / Apple-logo hangs: WebKit/AVFoundation are not loaded at boot; libroothide is not linked into SpringBoard.
- A C constructor blocks SplashBoard, SpringBoard, Sileo and system daemons before any Objective-C runs.
- Stable on iOS 14–18 / RootHide / rootless / rootful.

## 1.3.3 (2026-09-14)

### Tiếng Việt
- Sửa treo Sileo / SpringBoard: không còn inject vào SpringBoard, Sileo, Zebra, Cydia, WebKit.Networking.
- Gỡ hook NSURLSessionTask resume (gây deadlock CFNetwork).
- Bỏ quét view nặng trên didMoveToSuperview / viewDidAppear.

### English
- Fixed Sileo / SpringBoard freezes: no longer injects into SpringBoard, Sileo, Zebra, Cydia, or WebKit.Networking.
- Removed NSURLSessionTask resume hook (CFNetwork deadlock).
- Dropped heavy view walking on didMoveToSuperview / viewDidAppear.

## 1.3.2 (2026-09-14)

### Tiếng Việt
- Sửa QC thỉnh thoảng vẫn hiện: chặn cả process WebKit.Networking (Safari/WebView).
- Bơm lại CSS/JS nếu app gỡ script; quét WebView khi app mở lại.
- Load tweak cả khi app chưa có bundle ID; chặn NSURLSessionTask lúc resume.

### English
- Fixed ads sometimes showing: also hooks WebKit.Networking (Safari/WebView traffic).
- Re-injects CSS/JS if the app strips scripts; rescans WebViews when returning to the app.
- Starts even if the bundle ID is not ready yet; cancels ad NSURLSessionTasks on resume.

## 1.3.1 (2026-09-14)

### Tiếng Việt
- Sửa lỗi thỉnh thoảng không chặn được quảng cáo (tweak load lúc app chưa có bundle ID).
- Bơm lại CSS/JS khi WebView điều hướng; biên dịch content rule có retry.
- Hook SDK/IMA khi dylib quảng cáo load muộn; chặn download task và Safari View.

### English
- Fixed ads sometimes slipping through when the tweak loaded before the app bundle ID was ready.
- Re-injects CSS/JS on WebView navigations and retries content-rule compile.
- Hooks ad SDKs/IMA if they load late; blocks download tasks and Safari View Service.

## 1.3.0 (2026-09-14)

### Tiếng Việt
- Sileo hiện nhật ký mọi phiên bản khi xem/cài gói (mô tả + depiction native).
- Cài đặt → AdShield → Nhật ký phiên bản để theo dõi update trên máy.
- Đóng gói changelog Debian và trang depiction HTML cho Zebra/Cydia.

### English
- Sileo now shows a full version history on the package page (description + native depiction).
- Settings → AdShield → Changelog to follow updates on-device.
- Ships a Debian changelog and an HTML depiction for Zebra/Cydia.

## 1.2.2 (2026-09-14)

### Tiếng Việt
- Sửa Cài đặt tự thoát khi bấm App/Web trong Whitelist và Blacklist.
- Mở list bằng nút action + màn hình thường, không dùng detail PreferenceLoader.

### English
- Fixed Settings crashing when opening App/Web in Whitelist and Blacklist.
- Lists open via button actions and a normal screen, not PreferenceLoader detail pages.

## 1.2.1 (2026-09-14)

### Tiếng Việt
- Sửa crash PreferenceLoader khi mở whitelist/blacklist (chuyển sang PSListController).

### English
- Fixed PreferenceLoader crash on whitelist/blacklist (PSListController).

## 1.2.0 (2026-09-14)

### Tiếng Việt
- Whitelist: chọn app đã cài hoặc nhập domain để không chặn quảng cáo.
- Blacklist: thêm app luôn chặn (kể cả app Apple) và thêm host quảng cáo.
- Cài đặt → Tài trợ: MB Bank - 0345140889 - Nguyễn Tiến Triều.

### English
- Whitelist: pick installed apps or domains that should keep ads.
- Blacklist: force-block extra apps (including Apple apps) and extra ad hosts.
- Settings → Donate: MB Bank - 0345140889 - Nguyễn Tiến Triều.

## 1.1.1 (2026-09-14)

### Tiếng Việt
- Gói RootHide (iphoneos-arm64e) cho Dopamine-roothide / RootHide Bootstrap.
- Tự tìm jbroot nên prefs, relay plist và Respring chạy khi đường dẫn jailbreak bị random.

### English
- RootHide package (iphoneos-arm64e) for Dopamine-roothide / RootHide Bootstrap.
- Runtime jbroot so prefs, relay plist and Respring work with a randomized jailbreak root.

## 1.1.0 (2026-09-13)

### Tiếng Việt
- Chặn video quảng cáo: Google IMA / VAST, URL player native, skip preroll YouTube trên web.
- Bơm CSS/JS lúc trang bắt đầu tải trên Safari, SFSafariViewController và WebView trong app.
- MutationObserver và nút Skip Ad cho quảng cáo chèn muộn.

### English
- Video ads: Google IMA / VAST, native player ad URLs, YouTube web preroll skip.
- CSS/JS at document-start on Safari, SFSafariViewController and in-app WebViews.
- MutationObserver and Skip Ad tap for late-inserted units.

## 1.0.0 (2026-09-13)

### Tiếng Việt
- Bản đầu: chặn request mạng, SDK (AdMob, FAN, AppLovin, Unity, ironSource, …), WebView và banner native.
- Gói rootless (Dopamine) và rootful.

### English
- Initial release: network requests, ad SDKs (AdMob, FAN, AppLovin, Unity, ironSource, …), WebView and native banners.
- Rootless (Dopamine) and rootful packages.
