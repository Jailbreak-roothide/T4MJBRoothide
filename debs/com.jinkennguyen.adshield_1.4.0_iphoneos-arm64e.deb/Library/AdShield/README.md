# AdShield

System-wide ad blocker for jailbroken iOS. Aimed at comic readers, news apps, Safari, and other third-party apps.

**Credit: Jinken Nguyen - 1989**

## 1.3.1

- Fixed ads sometimes appearing because AdShield skipped the process when the bundle ID was not ready yet
- Retries WebView content rules and re-injects CSS/JS on navigation
- Hooks ad SDKs / IMA if they load after launch; Safari View Service is no longer skipped

## 1.3.0

- Sileo package page shows a full **Changelog** tab (native depiction) plus version history in the package description
- Settings → AdShield → Changelog / Nhật ký phiên bản

## 1.2.2

- Fixed Settings crashing when opening App / Web in Whitelist and Blacklist

## 1.2.1

- PreferenceLoader crash fix for whitelist/blacklist pages

## 1.2.0

- Whitelist: pick apps or websites that keep ads
- Blacklist: extra apps (overrides Skip Apple apps) and extra ad hosts
- Settings → Donate / Tài trợ (MB Bank - 0345140889 - Nguyễn Tiến Triều)

## 1.1.1

- RootHide package (`iphoneos-arm64e`) for Dopamine-roothide / RootHide Bootstrap
- Runtime `jbroot` so prefs, relay plist and Respring work when the jailbreak root is randomized

## 1.1.0

- Video ads: Google IMA / VAST, AVPlayer URLs on ad CDNs, YouTube web preroll skip
- CSS + JS injected at **document-start** so banners are hidden while the page loads
- Safari and `SFSafariViewController` (even when “Skip Apple apps” is on)
- MutationObserver + skip-ad click for late-inserted units

## What it does

1. **Network** — drops requests to known ad hosts
2. **SDK** — no-ops load/show on AdMob, FAN, AppLovin, Unity, ironSource, IMA, …
3. **Web** — WKContentRuleList + CSS/JS at load (in-app WebView, Safari, Chrome)
4. **Video** — blocks IMA/VAST, ad media URLs, skips YouTube web ads when possible
5. **Banners** — hides leftover native ad views

Apple apps are skipped by default, except Safari when that toggle is on. SpringBoard, Settings and WebKit helper processes are never injected.

## Install

| File | Jailbreak |
| --- | --- |
| `com.jinkennguyen.adshield_*_iphoneos-arm64e.deb` | RootHide (Dopamine-roothide, RootHide Bootstrap) |
| `com.jinkennguyen.adshield_*_iphoneos-arm64.deb` | Rootless (Dopamine, palera1n rootless) |
| `com.jinkennguyen.adshield_*_iphoneos-arm.deb` | Rootful (unc0ver, checkra1n, palera1n rootful) |

Install with Filza, Sileo, Zebra or `dpkg -i`, then **Respring**.

Open **Settings → AdShield**. After changing options or lists, force-quit the target app **and Safari**.

**Whitelist** turns blocking off for chosen apps and sites. **Blacklist** forces blocking in chosen apps and adds extra ad hosts. Do not put a whole news site on the web blacklist or that site itself will be blocked.

## Requirements

- iOS 14 and later
- arm64 / arm64e
- Cydia Substrate / Substitute / ElleKit (MobileSubstrate)
- PreferenceLoader

## Safety

- Kill file: `/var/mobile/Library/Preferences/.adshield-disable` then Respring
- Safe Mode does not load the tweak
- Does not inject SpringBoard, Preferences, or `com.apple.WebKit.*`

Some readers bake ads into first-party chapter HTML; those need extra host rules. The official YouTube **app** uses a custom player — web YouTube in Safari is the path that skips prerolls.

## Build

```sh
./scripts/build.sh
```

`build.sh` produces three debs in `packages/`: rootless (`iphoneos-arm64`), rootful (`iphoneos-arm`), and RootHide (`iphoneos-arm64e`). The RootHide build uses `$HOME/theos-roothide` (cloned from [roothide/theos](https://github.com/roothide/theos) on first run).
